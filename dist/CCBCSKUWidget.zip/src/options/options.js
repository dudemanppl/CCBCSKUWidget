document.onclick = () => console.log("nice");

console.log("nice");
