document.getElementById("shippingAddress_line1").value = "140 genoa street";
document.getElementById("shippingAddress_line2").value = "";
document.getElementById("shippingAddress_town").value = "arcadia";
document.getElementById("shippingAddress_postalCode").value = "91006";
document.getElementById("shippingAddress_email").value =
  "tommyliao340@gmail.com";
